Component({
  properties: {
    title: {
      type: String,
      value: '结果'
    },
    value: {
      type: String,
      value: '0'
    },
    unit: {
      type: String,
      value: ''
    }
  }
});