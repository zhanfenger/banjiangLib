Component({
  properties: {},
  data: {},
  methods: {}
});