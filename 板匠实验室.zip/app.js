App({
  onLaunch() {
    console.log("小程序启动");
  },
  globalData: {
    userInfo: null
  }
});